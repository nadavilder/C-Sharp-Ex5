﻿using System;
using System.Text;

namespace B21_Ex05_Shahar_311359566_Nadav_312173776
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Game.InitializeGame();
        }
    }
}